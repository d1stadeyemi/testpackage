# mypackage
This library was created as an example of how to create a package

# Building this package locally
"python setup.py sdist"